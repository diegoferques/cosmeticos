
package com.cosmeticos.cielo.model;


public class Link {

    public String method;
    public String rel;
    public String href;

}
