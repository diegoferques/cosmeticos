
package com.cosmeticos.cielo.model;

import java.util.List;

public class CaptureResponse {

    public Integer status;
    public String returnCode;
    public String returnMessage;
    public List<Link> links = null;

}
